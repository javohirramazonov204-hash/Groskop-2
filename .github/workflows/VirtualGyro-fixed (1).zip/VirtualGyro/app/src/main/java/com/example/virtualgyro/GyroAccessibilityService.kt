package com.example.virtualgyro

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Path
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.util.DisplayMetrics
import android.view.Surface
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import kotlin.math.abs
import kotlin.math.sqrt

class GyroAccessibilityService : AccessibilityService(), SensorEventListener {

    private lateinit var sensorManager: SensorManager
    private var listening = false

    // Sensor turlari: avval rotation vector (tayyor, shovqini kam), bo'lmasa accel+magnit
    private var rotationSensor: Sensor? = null
    private var accelerometer: Sensor? = null
    private var magnetometer: Sensor? = null

    private val gravity = FloatArray(3)
    private val magnetic = FloatArray(3)
    private var hasGravity = false
    private var hasMagnetic = false

    private val rawMatrix = FloatArray(9)
    private val screenMatrix = FloatArray(9)
    private val prevMatrix = FloatArray(9)
    private var hasPrev = false

    // To'plangan burilish (radian): X = tepaga/pastga qarash, Y = chapga/o'ngga qarash
    private var accPitch = 0f
    private var accYaw = 0f

    private var swiping = false
    private var lastCalibrationRequest = 0L

    private val prefs by lazy { getSharedPreferences("gyro_settings", Context.MODE_PRIVATE) }

    // Kuchli havola kerak: SharedPreferences listener'ni zaif saqlaydi
    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        when (key) {
            "gyro_enabled" -> syncListening()
            "calibration_request" -> resetBaseline()
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        rotationSensor = sensorManager.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR)
            ?: sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        if (rotationSensor == null) {
            accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
            magnetometer = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)
        }
        lastCalibrationRequest = prefs.getLong("calibration_request", 0L)
        prefs.registerOnSharedPreferenceChangeListener(prefListener)
        syncListening()
    }

    /** Sensorlar faqat Virtual Gyro yoqilganda ishlaydi (batareya tejaladi). */
    private fun syncListening() {
        if (!::sensorManager.isInitialized) return
        val enabled = prefs.getBoolean("gyro_enabled", false)
        if (enabled && !listening) {
            resetBaseline()
            val rate = SensorManager.SENSOR_DELAY_GAME
            if (rotationSensor != null) {
                sensorManager.registerListener(this, rotationSensor, rate)
            } else {
                accelerometer?.let { sensorManager.registerListener(this, it, rate) }
                magnetometer?.let { sensorManager.registerListener(this, it, rate) }
            }
            listening = true
        } else if (!enabled && listening) {
            sensorManager.unregisterListener(this)
            listening = false
        }
    }

    private fun resetBaseline() {
        hasPrev = false
        accPitch = 0f
        accYaw = 0f
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event == null) return

        when (event.sensor.type) {
            Sensor.TYPE_GAME_ROTATION_VECTOR, Sensor.TYPE_ROTATION_VECTOR -> {
                SensorManager.getRotationMatrixFromVector(rawMatrix, event.values)
            }
            Sensor.TYPE_ACCELEROMETER -> {
                lowPass(gravity, event.values, hasGravity)
                hasGravity = true
                if (!hasMagnetic) return
                if (!SensorManager.getRotationMatrix(rawMatrix, null, gravity, magnetic)) return
            }
            Sensor.TYPE_MAGNETIC_FIELD -> {
                lowPass(magnetic, event.values, hasMagnetic)
                hasMagnetic = true
                if (!hasGravity) return
                if (!SensorManager.getRotationMatrix(rawMatrix, null, gravity, magnetic)) return
            }
            else -> return
        }

        // Ekran o'qlariga moslash (portrait / landscape)
        val (axisX, axisY) = when (currentRotation()) {
            Surface.ROTATION_90 -> SensorManager.AXIS_Y to SensorManager.AXIS_MINUS_X
            Surface.ROTATION_180 -> SensorManager.AXIS_MINUS_X to SensorManager.AXIS_MINUS_Y
            Surface.ROTATION_270 -> SensorManager.AXIS_MINUS_Y to SensorManager.AXIS_X
            else -> SensorManager.AXIS_X to SensorManager.AXIS_Y
        }
        if (!SensorManager.remapCoordinateSystem(rawMatrix, axisX, axisY, screenMatrix)) return

        if (!hasPrev) {
            System.arraycopy(screenMatrix, 0, prevMatrix, 0, 9)
            hasPrev = true
            return
        }

        // Nisbiy burilish M = prev^T * cur. Kichik burchak uchun M ning antisimmetrik qismi
        // qurilmaning o'z o'qlari atrofidagi burilishni beradi (gimbal lock muammosi yo'q).
        val m = relative(prevMatrix, screenMatrix)
        val thetaX = (m[7] - m[5]) / 2f   // ekranning o'ng o'qi atrofida: tepaga/pastga
        val thetaY = (m[2] - m[6]) / 2f   // ekranning tepa o'qi atrofida: chapga/o'ngga
        System.arraycopy(screenMatrix, 0, prevMatrix, 0, 9)

        accPitch += thetaX
        accYaw += thetaY

        if (swiping) return

        val sensitivity = prefs.getFloat("sensitivity", 800f)
        val invertX = prefs.getBoolean("invert_x", false)
        val invertY = prefs.getBoolean("invert_y", false)

        // Yaw>0: chapga qarash -> barmoq chapga (manfiy X). Pitch>0: tepaga qarash -> barmoq tepaga (manfiy Y).
        var moveX = -accYaw * sensitivity
        var moveY = -accPitch * sensitivity
        if (invertX) moveX = -moveX
        if (invertY) moveY = -moveY

        // Juda qisqa swipe tizim tomonidan "tap" deb o'qiladi (o'yinda otish bo'lib ketadi),
        // shuning uchun touch slop'dan katta bo'lganda yuboramiz.
        val minDistance = ViewConfiguration.get(this).scaledTouchSlop * 2.5f
        if (sqrt(moveX * moveX + moveY * moveY) >= minDistance) {
            accPitch = 0f
            accYaw = 0f
            performCameraSwipe(moveX, moveY)
        }
    }

    private fun lowPass(target: FloatArray, input: FloatArray, initialised: Boolean) {
        val alpha = 0.15f
        for (i in 0..2) {
            target[i] = if (initialised) target[i] + alpha * (input[i] - target[i]) else input[i]
        }
    }

    /** a^T * b, 3x3 qatorlar bo'yicha (row-major). */
    private fun relative(a: FloatArray, b: FloatArray): FloatArray {
        val out = FloatArray(9)
        for (r in 0..2) {
            for (c in 0..2) {
                var s = 0f
                for (k in 0..2) s += a[k * 3 + r] * b[k * 3 + c]
                out[r * 3 + c] = s
            }
        }
        return out
    }

    @Suppress("DEPRECATION")
    private fun currentRotation(): Int {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        return wm.defaultDisplay.rotation
    }

    @Suppress("DEPRECATION")
    private fun screenSize(): Pair<Int, Int> {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val dm = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(dm)
        return dm.widthPixels to dm.heightPixels
    }

    private fun performCameraSwipe(moveX: Float, moveY: Float) {
        if (swiping) return
        swiping = true

        val (w, h) = screenSize()
        val startX = w * 0.75f
        val startY = h * 0.5f
        val endX = (startX + moveX).coerceIn(w * 0.5f, w * 0.95f)
        val endY = (startY + moveY).coerceIn(h * 0.1f, h * 0.9f)

        val path = Path().apply {
            moveTo(startX, startY)
            lineTo(endX, endY)
        }

        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 30))
            .build()

        val accepted = dispatchGesture(
            gesture,
            object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    swiping = false
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    swiping = false
                }
            },
            null
        )

        if (!accepted) swiping = false
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    // onInterrupt vaqtinchalik: sensorni o'chirmaymiz (avval shu yerda gyro butunlay to'xtab qolardi)
    override fun onInterrupt() {
        swiping = false
    }

    override fun onDestroy() {
        prefs.unregisterOnSharedPreferenceChangeListener(prefListener)
        if (::sensorManager.isInitialized) sensorManager.unregisterListener(this)
        listening = false
        super.onDestroy()
    }
}
